@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws/")
package com.soap.ws.client_jp;
