package ws;

public interface AddService {
	public int add(int a, int b);
}
